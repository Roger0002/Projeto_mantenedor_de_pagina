import os

TESTS_PATH = os.path.dirname(os.path.abspath(__file__))
